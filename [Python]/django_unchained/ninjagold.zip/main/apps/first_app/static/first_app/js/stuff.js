console.log("hello world!");
alert("good morning, Starshine, the Earth says hello!")
