module.exports = {
    addto: function(num1, num2) {
         console.log(num1 + num2)
    },
    multiply: function(num1, num2) {
         console.log(num1 * num2)
    },
    square: function(num) {
         console.log(num * num)
    },
    random: function() {
         console.log(Math.floor(Math.random(100)*100))
    }
};
