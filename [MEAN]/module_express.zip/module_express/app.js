var my_module = require('./modulex');
my_module.addto(400,20);
my_module.multiply(5,5);
my_module.square(5);
my_module.random();
