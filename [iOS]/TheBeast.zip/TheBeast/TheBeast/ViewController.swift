//
//  ViewController.swift
//  TheBeast
//
//  Created by Jaeson Booker on 3/14/17.
//  Copyright © 2017 Jaeson Booker. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var tasks = ["Chuck Norris", "Bruce Wayne", "Clark Kent"]
    @IBOutlet weak var taskTextField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    @IBAction func buttonohbutton(_ sender: UIButton) {
        let content = taskTextField.text
        taskTextField.text = ""
        tasks.append(content!)
            tableView.reloadData()
        }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int)
    -> Int {
        return tasks.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)
        -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "prototype", for: indexPath)
            cell.textLabel?.text = tasks[indexPath.row]
            let age = arc4random_uniform(95-5)+5
            cell.detailTextLabel?.text = "\(100-age)"
            return cell
    }
}

